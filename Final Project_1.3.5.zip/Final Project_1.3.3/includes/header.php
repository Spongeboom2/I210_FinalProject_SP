<?php

if(session_status() == PHP_SESSION_NONE) {
    session_start();
}


//number of items in the shooping cart
$count=0;

//retrieve cart content
if(isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];

    if($cart) {
        $count = array_sum($cart);
    }
}

//set shopping cart image
$shoppingcart_img = (!$count) ? "shoppingcart_empty.gif" : "shoppingcart_full.gif";

$login = $name = $role = 0;

if(isset($_SESSION['login']) AND isset($_SESSION['name']) AND
    isset($_SESSION['role'])) {
    $login = $_SESSION['login'];
    $name = $_SESSION['name'];
    $role = $_SESSION['role'];
}
?>

<!--HTML Starts Here-->
<!DOCTYPE html>
<html>
<Head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link type="text/css" rel="stylesheet" href="www/css/GalaxyStyleSheets.css" />
    <title><?php echo $page_title ?></title>
</Head>

<div class="navbar">

    <div id="navbarLeft">
    <a class="<?php if($page=='home'){echo 'active';} ?>" href="index.php">Home</a>
    <a class="<?php if($page=='aboutUs'){echo 'active';} ?>" href="aboutUs.php">About Us</a>
    <a class="<?php if($page=='ourGames'){echo 'active';} ?>" href="inventory.php">Our Games</a>
    </div>
    <!--Logo-->
        <div>
         <img id="logo" src="www/images/GGlogo.png" alt="Logo">
        </div>
    <!--Logo-->
    <div id="navbarRight">
    <a class="<?php if($page=='ourGames'){echo 'active';} ?>" href="searchGames.php">Search Games</a>
    <a class="<?php if($page=='ourGames'){echo 'active';} ?>" href="showcart.php">Shopping Cart</a>
        <?php
        if ($role == 1) {
            echo "<a href='addgame.php'>Add Game</a> || ";
        }
        if (empty($login))
            echo "<a href='loginform.php'>Login</a>";
        else {
            echo "<a href='logout.php'>Logout</a>";
            echo "<span style='color:red; margin-left:30px'>Welcome $name!</span>";
        }
        ?>
    </div>
</div>


<!--Logo image and banner text-->
<div class ="belowHeader">
    <div id="logo">

    </div>
    <div id="pageTitle">
        <h2 id="pageName"><?= $page_name ?></h2>
    </div>
</div>
<body class="body">

</body>
<!--Webpage Body Ends here-->

</html>
<!--HTML Ends here-->
