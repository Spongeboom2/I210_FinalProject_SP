</div>

<div id="footer">
    &copy <?php echo date("Y") ?> PHP Online Bookstore. All Rights Reserved.
</div>

</body>
</html>