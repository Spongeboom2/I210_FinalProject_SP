<?php
//define parameters
$host = "localhost";
$login = "phpuser";
$password = "phpuser";
$database = "usedvideogames";
$tblVideo = "videogames";
$tblCategory = "categories";
$tblUser = "users";

// connect to the mysql server
$conn = @new mysqli($host, $login, $password, $database);

//handle errors
if($conn ->connect_errno) {
    $error = $conn->connect_error;
    header("location:error.php?m=$error");
    die();
}
