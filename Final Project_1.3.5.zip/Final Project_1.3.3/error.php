<?php
/**
 * Authors: Ryan Stump, Parker Staph, Alex Young, Sean Birkle
 */

$page_title = "Error";
$page_name = "Errors = not poggers";

//Header of the webpage
include ('includes/header.php');
?>

<!--HTML Starts Here-->
<!DOCTYPE html>
<html>
<Head>
    <link rel="stylesheet" href="www/css/Stylesheet.css">
    <title>Home Page</title>
</Head>


<!--Webpage Body Starts Here-->
    <body class="body">
    <h2>Welcome to our video game store</h2>
    <p>Our website sells video games...etc.</p>



    </body>
<!--Webpage Body Ends here-->

<!--Footer Starts here-->
<?php
include ('includes/footer.php');
?>
</html>
<!--HTML Ends here-->
