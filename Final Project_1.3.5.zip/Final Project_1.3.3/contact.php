<?php
/**
 * Authors: Ryan Stump, Parker Staph, Alex Young, Sean Birkle
 */

$page_title = "Index";
$page_name = "Contact Page";

//Header of the webpage
include ('includes/header.php');
?>
    <p>Please fill out the contact form below and we will respond within 24 hours</p>

Include contact form here

    <!--Footer Starts here-->
<?php
include ('includes/footer.php');
?>
    </html>
    <!--HTML Ends here--><?php
